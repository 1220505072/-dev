#include <stdio.h>
#include <conio.h>

int main()
{
  int enk, i, n;
  int dizi[n];
  printf("Dizinin Eleman Sayisini Giriniz :");
  scanf("%d", &n);
  for (i = 1; i <= n; i++)                         //2n+2
  {
    printf("%d . elememani giriniz : ", i);
    scanf("%d", &dizi[i]);
  }
  enk = dizi[1];                                     //1
  for (i = 2; i <= n; i++)                             //2n+2
  {
    if (dizi[i] < enk)                                   //n
      enk = dizi[i];                                      //n
  }
  
  printf("En kucuk sayi : %d",enk);
  getch();
}                                                               // T(n)=6n+5
